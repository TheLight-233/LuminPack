﻿namespace LuminPack.Interface
{
    public interface ILuminPackParserBehaviour<in T>
    {
        void RegisterParser();
        
    }
}