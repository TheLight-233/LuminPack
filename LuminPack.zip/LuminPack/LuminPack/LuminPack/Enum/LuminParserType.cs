namespace LuminPack.Enum;

public enum LuminParserType : byte
{
    UnSupportType,
    Unmanaged,
    String,
    Dictionary,
}