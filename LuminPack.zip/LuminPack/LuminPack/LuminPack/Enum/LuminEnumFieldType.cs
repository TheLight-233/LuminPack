﻿namespace LuminPack.Enum
{
    public enum LuminEnumFieldType : byte
    {
        Byte,
        Short,
        Int,
        Long,
        Float,
        Double
    }
}