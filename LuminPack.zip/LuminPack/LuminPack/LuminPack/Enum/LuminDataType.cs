﻿namespace LuminPack.Enum
{
    
    public enum LuminDataType : byte
    {
        Reference,
        Value
    }
}