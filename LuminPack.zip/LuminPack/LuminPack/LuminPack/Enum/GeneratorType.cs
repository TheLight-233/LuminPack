namespace LuminPack.Enum;

public enum GeneratorType : byte
{
    Object,
    VersionTolerant,
    CircleReference,
    NonGenerator
}