﻿namespace LuminPack.Enum
{
    public enum LuminFiledType : byte
    {
        Int,
        Byte,
        Short,
        Long,
        Float,
        Double,
        String,
        Bool,
        Enum,
        Struct,
        Class,
        List,
        Array,
    }
}