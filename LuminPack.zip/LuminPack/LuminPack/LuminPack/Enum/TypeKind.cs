namespace LuminPack.Enum;

internal enum TypeKind : byte
{
    None,
    UnmanagedSzArray,
    FixedSizeLuminPackable
}