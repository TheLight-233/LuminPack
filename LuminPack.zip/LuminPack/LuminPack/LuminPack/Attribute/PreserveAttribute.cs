﻿namespace LuminPack.Attribute
{
    public sealed class PreserveAttribute : System.Attribute
    {
        
    }
}