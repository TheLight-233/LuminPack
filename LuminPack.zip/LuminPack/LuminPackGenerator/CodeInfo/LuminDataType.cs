﻿namespace LuminPack.Code
{
    
    public enum LuminDataType : byte
    {
        Reference,
        Value
    }
}