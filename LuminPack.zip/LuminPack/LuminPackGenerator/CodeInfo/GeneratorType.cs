namespace LuminPack.Code;

public enum GeneratorType : byte
{
    Object,
    VersionTolerant,
    CircleReference,
    NonGenerator,
}