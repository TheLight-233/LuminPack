namespace LuminPack.Code;

public enum StructLayout
{
    Auto = 0,
    Sequential = 2,
    Explicit = 3,
    Default = 255,
}