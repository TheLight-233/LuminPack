namespace LuminPack.Code;

public sealed class LuminLocalFieldData
{
    public string TypeName;
    public string Name;
    public int filedOffset;
    public bool IsValue;
}