﻿namespace LuminPack.Code
{
    public enum LuminEnumFieldType : byte
    {
        Byte,
        Short,
        UShort,
        Int,
        UInt,
        Long,
        ULong,
        Float,
        Double
    }
}