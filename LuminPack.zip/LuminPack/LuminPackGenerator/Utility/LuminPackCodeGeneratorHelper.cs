namespace LuminPack.SourceGenerator.Utility;

public static class LuminPackCodeGeneratorHelper
{
    //0-*为数组长度，-1表示空集合
    public const int NullCollection = -1;

    public const byte NullObject = 255;
}